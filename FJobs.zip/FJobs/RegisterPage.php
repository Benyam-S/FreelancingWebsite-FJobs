<?php
$server_name = "localhost";
$db_name = "FJob";
$user_name = "root";


function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}


if (isset($_POST['firstName'])) {
    $firstName = test_input($_POST['firstName']);
} else {
    echo "Please fill first name";
    return;
}

if (isset($_POST['lastName'])) {
    $lastName = test_input($_POST['lastName']);
} else {
    echo "Please fill lastName";
    return;
}

if (isset($_POST['email'])) {
    $email = test_input($_POST['email']);
} else {
    echo "Please use valid email";
    return;
}

if (isset($_POST['phoneNumber'])) {
    $phoneNumber = test_input($_POST['phoneNumber']);
} else {
    echo "Please use valid phoneNumber";
    return;
}

if (isset($_POST['password'])) {
    $password = sha1(test_input($_POST['password']));
} else {
    echo "Please enter password";
    return;
}


if (isset($_POST['jobTitle'])) {
    $jobTitle = test_input($_POST['jobTitle']);
}

if (isset($_POST['aboutYou'])) {
    $aboutYou = test_input($_POST['aboutYou']);
}else {
    $aboutYou = '';
}

if (isset($_POST['country'])) {
    $country = test_input($_POST['country']);
}

if (isset($_POST['city'])) {
    $city = test_input($_POST['city']);
}
if (isset($_POST['gender'])) {
    $gender = test_input($_POST['gender']);
}
if (isset($_POST['prefer'])) {
    $prefer = test_input($_POST['prefer']);
}
try {

    if (empty($jobTitle)) {
        $jobTitle = 'empty';
    }
    if (empty($aboutYou)) {
        $aboutYou = 'empty';
    }
    if (empty($coutnry)) {
        $country = 'empty';
    }
    if (empty($city)) {
        $city = 'empty';
    }
    if (empty($prefer)) {
        $prefer = "no";
    }
    $connection = new PDO("mysql:hostname=$server_name;dbname=$db_name", $user_name, "");
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $countStatment = $connection -> prepare("SELECT COUNT(ID) FROM UserAccount");
    $countStatment -> execute();
    $userCount = $countStatment->setFetchMode(PDO::FETCH_ASSOC);
    $countResult = $countStatment -> fetchAll();

    if(count($countResult) > 0){
        foreach ($countResult as $k => $v){
            foreach($v as $f){
                $userID = "FJ".$f;
            } 
        }
    }else{
        $userID = "FJ0";
    }

    $stm = $connection->prepare("INSERT INTO useraccount (ID,firstName, lastName,password, jobTitle,aboutYou, country, city, gender, prefer, email, phoneNumber)
      VALUES (:userID,:firstName,:lastName,:password,:jobTitle,:aboutYou,:country,:city,:gender,:prefer,:email,:phoneNumber)");
    $stm->bindParam(':userID', $userID);
    $stm->bindParam(':firstName', $firstName);
    $stm->bindParam(':lastName', $lastName);
    $stm->bindParam(':password', $password);
    $stm->bindParam(':jobTitle', $jobTitle);
    $stm->bindParam(':aboutYou', $aboutYou);
    $stm->bindParam(':country', $country);
    $stm->bindParam(':city', $city);
    $stm->bindParam(':gender', $gender);
    $stm->bindParam(':prefer', $prefer);
    $stm->bindParam(':email', $email);
    $stm->bindParam(':phoneNumber', $phoneNumber);

    setcookie('userID',$userID,time() + (86400 * 30));

    $stm->execute();

    echo "Okay";
} catch (PDOException $e) {
    echo $e->getMessage();
}


$connection = null;
