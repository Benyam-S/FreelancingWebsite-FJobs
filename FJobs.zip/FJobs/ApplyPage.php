<?php
$server_name = "localhost";
$db_name = "FJob";
$user_name = "root";



if (isset($_POST['projectID'])) {
    $projectID = test_input($_POST['projectID']);  
} else {
    echo "Error";
    return;
}

if (isset($_POST['message'])) {
    $message = test_input($_POST['message']);
    if (strlen($message) < 8) {
        echo "message too short";
        return;
    }
} else {
    echo "message too short";
    return;
}

if (isset($_POST['applierID'])) {
    $applierID = test_input($_POST['applierID']);
    
} else {
    echo "Error";
    return;
}


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }


try{
    $connection = new PDO("mysql:hostname=$server_name;dbname=$db_name",$user_name,"");
    $connection -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stm = $connection -> prepare("INSERT INTO applyTable (projectID,message,applierID) 
    VALUES (:projectID,:message,:applierID)");

    $stm -> bindParam(':projectID',$projectID);
    $stm -> bindParam(':message',$message);
    $stm -> bindParam(':applierID',$applierID);
    
    $stm -> execute();

    echo "Okay";

    
}
catch(PDOException $e){
    echo $e -> getMessage();
}

$connection = null;


?>