<?php
$server_name = "localhost";
$db_name = "FJob";
$user_name = "root";

if (isset($_POST['userID'])) {
    $userID = test_input($_POST['userID']);
} else {
    echo "Error";
    return;
}
if (isset($_POST['flag'])) {
    $flag = test_input($_POST['flag']);
} else {
    $flag = false;
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if($flag == false){
    $conn = new mysqli($server_name, $user_name, '', $db_name);
    $stmt = $conn->prepare("SELECT * FROM Project  WHERE projectProvider= ?");
    $stmt->bind_param("s", $userID);
    $stmt->execute();
    $result = $stmt->get_result();
    $outp = $result->fetch_all(MYSQLI_ASSOC);
    
    echo json_encode($outp);
}else{
    $conn = new mysqli($server_name, $user_name, '', $db_name);
    $stmt = $conn->prepare("SELECT * FROM Project  WHERE projectProvider <> ?");
    $stmt->bind_param("s", $userID);
    $stmt->execute();
    $result = $stmt->get_result();
    $outp = $result->fetch_all(MYSQLI_ASSOC);
    
    echo json_encode($outp);
}

    


class Project
{
    function Project($projectID, $title, $category, $subCategory, $description, $workType, $budget, $projectProvider)
    {
        $this->projectID = $projectID;
        $this->title = $title;
        $this->category = $category;
        $this->subCategory = $subCategory;
        $this->description = $description;
        $this->workType = $workType;
        $this->budget = $budget;
        $this->projectProvider = $projectProvider;
    }
}
// try {
    // $connection = new PDO("mysql:hostname=$server_name;dbname=$db_name",$user_name,"");
    // $connection -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // $query = $connection -> prepare("SELECT * FROM Project  WHERE projectProvider=:projectProvider");
    // $query -> bindParam(':projectProvider',$userID);
    // $query -> execute();
    // $queryR = $query->setFetchMode(PDO::FETCH_ASSOC);
    // $queryResult = $query->fetchAll();

    // if (count($queryResult) > 0) {
    //     foreach ($queryResult as $kv) {
    //         foreach ($kv as $k => $v) {
    //             echo $v;
    //             return;
    //         }
    //     }
    // } else {
    //     echo "Empty";
    //     return;
    // }

    // echo "Okay";
// } catch (PDOException $e) {
//     echo $e->getMessage();
// }
// $connection = null;
?>

