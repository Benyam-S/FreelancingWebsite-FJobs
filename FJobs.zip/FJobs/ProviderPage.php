<?php
$server_name = "localhost";
$db_name = "FJob";
$user_name = "root";



if (isset($_POST['title'])) {
    $title = test_input($_POST['title']);
    if (strlen($title) < 8) {
        echo "Title too short";
        return;
    }
    
} else {
    echo "Title too short";
    return;
}

if (isset($_POST['category'])) {
    $category = test_input($_POST['category']);
    if ($category == '') {
        echo "Fill category";
        return;
    }
} else {
    echo "Fill category";
    return;
}

if (isset($_POST['subCategory'])) {
    $subCategory = test_input($_POST['subCategory']);
}

if (isset($_POST['description'])) {
    $description = test_input($_POST['description']);
    if (strlen($description) < 8) {
        echo "Description too short";
        return;
    }
} else {
    echo "Description too short";
    return;
}
if (isset($_POST['workType'])) {
    $workType = test_input($_POST['workType']);
    if (empty($workType)) {
        echo "Fill work type";
        return;
    }
} else {
    echo "Fill work type";
    return;
}
if (isset($_POST['budget'])) {
    $budget = test_input($_POST['budget']);
    if (($workType == "fixed_price" || $workType == "per_hour") && empty($budget)) {
        echo "Fill budget";
        return;
    }
} else {
    echo "Fill budget";
    return;
}

if (isset($_POST['projectProvider'])) {
    $projectProvider = test_input($_POST['projectProvider']);

} else {
    echo "Error";
    return;
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }


try{
    $connection = new PDO("mysql:hostname=$server_name;dbname=$db_name",$user_name,"");
    $connection -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $countStatment = $connection -> prepare("SELECT COUNT(projectID) FROM Project");
    $countStatment -> execute();
    $projectCount = $countStatment->setFetchMode(PDO::FETCH_ASSOC);
    $countResult = $countStatment -> fetchAll();

    if(count($countResult) > 0){
        foreach ($countResult as $k => $v){
            foreach($v as $f){
                $projectID = "PJ".$f;
            } 
        }
    }else{
        $projectID = "PJ0";
    }

    $stm = $connection -> prepare("INSERT INTO Project (projectID,title,category,subCategory,description,workType,budget,projectProvider) 
    VALUES (:projectID,:title,:category,:subCategory,:description,:workType,:budget,:projectProvider)");

    $stm -> bindParam(':projectID',$projectID);
    $stm -> bindParam(':title',$title);
    $stm -> bindParam(':category',$category);
    $stm -> bindParam(':subCategory',$subCategory);
    $stm -> bindParam(':description',$description);
    $stm -> bindParam(':workType',$workType);
    $stm -> bindParam(':budget',$budget);
    $stm -> bindParam(':projectProvider',$projectProvider);

    $stm -> execute();

    echo "Okay";

    
}
catch(PDOException $e){
    echo $e -> getMessage();
}

$connection = null;


?>


