<?php

session_start();

$server_name = "localhost";
$db_name = "FJob";
$user_name = "root";
$invalidFlage = false;

if(isset($_POST['email'])){
    $email = test_input($_POST['email']);   
}
else{
    $invalidFlage = true;
}
if(isset($_POST['password'])){
    $password = sha1(test_input($_POST['password']));
}
else{
    $invalidFlage = true; 
}
if(isset($_POST['rememberMe'])){
    $rememberMe = test_input($_POST['rememberMe']);
}
else{
    $invalidFlage = true; 
}
if(!$invalidFlage){
    try{
        $connection = new PDO("mysql:hostname=$server_name;dbname=$db_name",$user_name,"");
        $connection -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stm = $connection -> prepare("SELECT ID FROM useraccount WHERE email = :email AND password = :password");
    
        $stm -> bindParam(':email',$email);
        $stm -> bindParam(':password',$password);
    
        $stm -> execute();
        $result = $stm -> setFetchMode(PDO::FETCH_ASSOC);
        $queryResult = $stm -> fetchAll();
        $length = count($queryResult);
        if($length > 0){
            foreach($queryResult as $ku){
                foreach($ku as $k => $v){
                    $userID = $v;
                }
            }
        
            $_SESSION['userID'] = $userID;
            setcookie('userID',$userID,time() + (86400 * 30));

            if($rememberMe == true){
                setcookie('userEmail',$email,time() + (86400 * 30));
                setcookie('password',$password,time() + (86400 * 30));
            }

            // header('Location: ProfilePage.html');
            echo "Okay";
        }
        else{
            echo 'Invalid';
        }
        
    }
    catch(PDOException $e){
        echo $e -> getMessage();
    }
    
    $connection = null;
}
else{
    echo "Invalid";
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }


?>