<?php
$server_name = "localhost";
$db_name = "FJob";
$user_name = "root";

if (isset($_POST['projectID'])) {
    $projectID = test_input($_POST['projectID']);
} else {
    echo "Error";
    return;
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

$connection = new mysqli($server_name, $user_name, '', $db_name);
$stmt = $connection->prepare("SELECT * FROM Project  WHERE projectID= ?");
$stmt->bind_param("s", $projectID);
$stmt->execute();
$result = $stmt->get_result();
$outp = $result->fetch_all(MYSQLI_ASSOC);
mysqli_close($connection);

echo json_encode($outp);

?>