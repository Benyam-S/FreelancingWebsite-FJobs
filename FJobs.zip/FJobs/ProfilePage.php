<?php
$server_name = "localhost";
$db_name = "FJob";
$user_name = "root";

if (isset($_POST['userID'])) {
    $userID = test_input($_POST['userID']);
} else {
    echo "Error";
    return;
}
if (isset($_POST['saveFlag'])) {
    $saveFlag = test_input($_POST['saveFlag']);
    if ($saveFlag == true) {
        $saveFlag = true;
    } else {
        $saveFlag = false;
    }
} else {
    $saveFlag = false;
}

if (isset($_POST['request'])) {
    $request = test_input($_POST['request']);
    if ($request == true) {
        $request = true;
    } else {
        $request = false;
    }
} else {
    $request = false;
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if ($saveFlag) {

    if (isset($_POST['firstName'])) {
        $firstName = test_input($_POST['firstName']);
    } else {
        echo "Please fill first name";
        return;
    }

    if (isset($_POST['lastName'])) {
        $lastName = test_input($_POST['lastName']);
    } else {
        echo "Please fill lastName";
        return;
    }

    if (isset($_POST['email'])) {
        $email = test_input($_POST['email']);
    } else {
        echo "Please use valid email";
        return;
    }

    if (isset($_POST['phoneNumber'])) {
        $phoneNumber = test_input($_POST['phoneNumber']);
    } else {
        echo "Please use valid phoneNumber";
        return;
    }

    if (isset($_POST['jobTitle'])) {
        $jobTitle = test_input($_POST['jobTitle']);
    }

    if (isset($_POST['aboutYou'])) {
        $aboutYou = test_input($_POST['aboutYou']);
    }

    if (isset($_POST['country'])) {
        $country = test_input($_POST['country']);
    }

    if (isset($_POST['city'])) {
        $city = test_input($_POST['city']);
    }
    if (isset($_POST['gender'])) {
        $gender = test_input($_POST['gender']);
    }
    if (isset($_POST['prefer'])) {
        $prefer = test_input($_POST['prefer']);
    }
    try {

        if (empty($jobTitle)) {
            $jobTitle = 'empty';
        }
        if (empty($aboutYou)) {
            $aboutYou = 'empty';
        }
        if (empty($coutnry)) {
            $country = 'empty';
        }
        if (empty($city)) {
            $city = 'empty';
        }
        if (empty($prefer)) {
            $prefer = "no";
        }
        $connection = new PDO("mysql:hostname=$server_name;dbname=$db_name", $user_name, "");
        $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stm = $connection->prepare("UPDATE UserAccount SET firstName=:firstName, lastName=:lastName, jobTitle=:jobTitle,
        aboutYou = :aboutYou, country = :country, city = :city, gender = :gender, prefer = :prefer, email = :email, phoneNumber = :phoneNumber WHERE ID = :userID");

        $stm->bindParam(':userID', $userID);
        $stm->bindParam(':firstName', $firstName);
        $stm->bindParam(':lastName', $lastName);
        $stm->bindParam(':jobTitle', $jobTitle);
        $stm->bindParam(':aboutYou', $aboutYou);
        $stm->bindParam(':country', $country);
        $stm->bindParam(':city', $city);
        $stm->bindParam(':gender', $gender);
        $stm->bindParam(':prefer', $prefer);
        $stm->bindParam(':email', $email);
        $stm->bindParam(':phoneNumber', $phoneNumber);

        $stm->execute();

        if (isset($_FILES['file'])){
            $profileImage = $_FILES['file']['name'];
            $target = "profileImages/".$_FILES['file']['name'];
            move_uploaded_file($_FILES['file']['tmp_name'], $target);

            $stm = $connection->prepare("UPDATE UserAccount SET profileImage = :profileImage WHERE ID = :userID");
            $stm->bindParam(':profileImage', $profileImage);
            $stm->bindParam(':userID', $userID);
            $stm->execute();
        }
        
        echo "Okay";
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
    

    $connection = null;
} elseif($request){

    $connection = new mysqli($server_name, $user_name, '', $db_name);
    $stmt = $connection->prepare("SELECT profileImage FROM UserAccount  WHERE ID= ?");
    $stmt->bind_param("s", $userID);
    $stmt->execute();
    $result = $stmt->get_result();
    $outp = $result->fetch_all(MYSQLI_ASSOC);
    $image = $outp[0]['profileImage'];
    $location = 'http://localhost/phpTest/ProjectFinal/profileImages/'.$image;
    mysqli_close($connection);
    echo ($location);
}
else {
    $connection = new mysqli($server_name, $user_name, '', $db_name);
    $stmt = $connection->prepare("SELECT * FROM UserAccount  WHERE ID= ?");
    $stmt->bind_param("s", $userID);
    $stmt->execute();
    $result = $stmt->get_result();
    $outp = $result->fetch_all(MYSQLI_ASSOC);
    mysqli_close($connection);
    echo json_encode($outp);
}
?>